const mongoLength = {
    name: 202,
    description: 10002,
    message: 10002,
    id: 202,
    progressId: 410,
}

const JoiLength = {
    name: 201,
    description: 10001,
    message: 10001,
    id: 201,
    progressId: 409,
}

module.exports.mongoLength = mongoLength
module.exports.JoiLength = JoiLength
