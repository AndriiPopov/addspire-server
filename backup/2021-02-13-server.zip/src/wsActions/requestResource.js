const { User } = require('../models/user')
const Joi = require('@hapi/joi')
const { Account } = require('../models/account')
const { Progress } = require('../models/progress')
const { Post } = require('../models/post')
const { get } = require('../startup/redis')
const { Board } = require('../models/board')
const { ProgressStep } = require('../models/progressStep')
const { Structure } = require('../models/structure')
const { Version } = require('../models/version')
const { Course } = require('../models/course')
const { Step } = require('../models/step')

// const validateSchema = Joi.object({
//     ids: Joi.array().items(Joi.string().optional()),
//     type: Joi.string().valid('user', 'website', 'resource'),
// }).unknown()

module.exports.requestResource = async (data, ws) => {
    try {
        // const { error } = validateSchema.validate(data)
        // if (error) return

        //Compare and send not found resources!!!!!!!!
        let result
        const onlineUsers = []
        if (data.type && data.ids && data.ids.length > 0) {
            let model
            let fields
            switch (data.type) {
                case 'user':
                    model = User
                    break
                case 'account':
                    model = Account
                    for (let user of data.ids)
                        if (await get(user)) onlineUsers.push(user)
                    break
                case 'board':
                    model = Board
                    break
                case 'course':
                    model = Course
                    break
                case 'post':
                    model = Post
                    break
                case 'progress':
                    model = Progress
                    break
                case 'progressStep':
                    model = ProgressStep
                    break
                case 'step':
                    model = Step
                    break
                case 'structure':
                    model = Structure
                    break
                case 'version':
                    model = Version
                    break

                case 'accountD':
                    model = Account
                    fields = 'name image notifications __v'
                    for (let user of data.ids)
                        if (await get(user)) onlineUsers.push(user)
                    break
                case 'boardD':
                    model = Board
                    fields =
                        'name likes followers images trend notifications __v'
                    break
                case 'courseD':
                    model = Course
                    fields =
                        'likes followers currentVersion trend notifications __v'
                    break
                case 'postD':
                    model = Post
                    fields = 'notifications __v'
                    break
                case 'progressD':
                    model = Progress
                    break
                case 'progressStepD':
                    model = ProgressStep
                    fields = 'step description status __v'
                    break
                case 'stepD':
                    model = Step
                    fields = 'name images __v'
                    break
                case 'structureD':
                    model = Structure
                    break
                case 'versionD':
                    model = Version
                    fields =
                        'name images category published description owner course __v'
                    break
                default:
                    break
            }

            if (model) {
                if (!fields) {
                    result = await model
                        .find({
                            _id: { $in: data.ids },
                        })
                        .lean()
                        .exec()
                } else {
                    result = await model
                        .find({
                            _id: { $in: data.ids },
                        })
                        .select(fields)
                        .lean()
                        .exec()
                }
            }

            if (result && result.length > 0) {
                for (let item of result) {
                    if (item)
                        ws.resources[data.type][item._id.toString()] =
                            result[0].__v
                }

                ws.send(
                    JSON.stringify({
                        messageCode: 'addResource',
                        type: data.type,
                        resources: result.filter(item => item),
                        newOnlineUsers: onlineUsers,
                    })
                )
            } else {
                if (!fields) {
                    ws.send(
                        JSON.stringify({
                            messageCode: '404',
                        })
                    )
                }
                ws.send(
                    JSON.stringify({
                        messageCode: 'notFoundResource',
                        _id: data.ids,
                    })
                )
            }
        }
    } catch (ex) {
        console.log(ex)
    }
}
