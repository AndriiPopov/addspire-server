const { Activity } = require('../models/activity')
const { Account } = require('../models/account')
const Joi = require('@hapi/joi')
const { JoiLength } = require('../constants/fieldLength')

const { sendError, sendSuccess } = require('./confirm')
const { Post } = require('../models/post')
const { getNotificationId } = require('../models/system')
const addNotification = require('../utils/addNotification')
const { updateStages } = require('../utils/updateStages')
const { Progress } = require('../models/progress')
const { Reward } = require('../models/reward')
const { Transaction } = require('../models/transaction')
const dayjs = require('dayjs')
var minMax = require('dayjs/plugin/minMax')
const getStageStartEnd = require('../utils/getStageStartEnd')

dayjs.extend(minMax)
dayjs().format()

module.exports.saveActivity = async (data, ws) => {
    try {
        if (data.accountId) {
            const account = await Account.findById(data.accountId).select(
                '__v activities wishlist notifications myPosts'
            )
            if (account) {
                const newData = {
                    name: data.activity.name,
                    images: data.activity.images,
                    description: data.activity.description,
                    descriptionText: data.activity.descriptionText,
                    repeat: data.activity.repeat,
                    days: data.activity.days,
                    category: data.activity.category,
                }
                const newNotificationId = await getNotificationId()

                if (data.activity._id) {
                    let activity = await Activity.findById(data.activity._id)
                    if (activity) {
                        activity = Object.assign(activity, newData)
                        updateStages(activity)
                        // const newNotificationIdPost = await getNotificationId()

                        // await Post.findOneAndUpdate(
                        //     { _id: activity.post },
                        //     {
                        //         $set: {
                        //             startMessage: {
                        //                 author: account._id,
                        //                 text: newData.description,
                        //                 action: 'edit activity',
                        //                 image: newData.images,
                        //                 messageId: '0',
                        //                 messageType: 'activity',
                        //                 details: {
                        //                     owner: account._id,
                        //                     name: newData.name,
                        //                     itemId: activity._id,
                        //                 },
                        //             },
                        //         },
                        //         $push: {
                        //             notifications: {
                        //                 $each: [
                        //                     {
                        //                         user: account._id,
                        //                         code: 'edit activity',
                        //                         notId: newNotificationIdPost,
                        //                         details: {
                        //                             itemId: activity._id,
                        //                         },
                        //                     },
                        //                 ],
                        //                 $position: 0,
                        //                 $slice: 20,
                        //             },
                        //         },
                        //     },
                        //     { useFindAndModify: false }
                        // )
                        await activity.save()
                        addNotification(account, {
                            user: account._id,
                            code: 'edit activity',
                            notId: newNotificationId,
                            details: {
                                itemId: activity._id,
                                itemName: newData.name,
                            },
                        })
                    }
                } else {
                    const activity = new Activity({
                        ...newData,
                        owner: account._id,
                    })
                    // const post = new Post({
                    //     users: [data.accountId],
                    //     parent: {
                    //         parentId: activity._id,
                    //         parentType: 'activity',
                    //     },
                    //     startMessage: {
                    //         author: data.accountId,
                    //         text: newData.description,
                    //         action: 'add activity',
                    //         image: newData.images,
                    //         messageId: '0',
                    //         messageType: 'activity',
                    //         details: {
                    //             owner: data.accountId,
                    //             name: newData.name,
                    //             itemId: activity._id,
                    //         },
                    //     },
                    // })
                    // await post.save()
                    // activity.post = post._id

                    // account.myPosts.push(post._id.toString())
                    await activity.save()

                    addNotification(account, {
                        user: account._id,
                        code: 'add activity',
                        notId: newNotificationId,
                        details: {
                            itemName: newData.name,
                            itemId: activity._id,
                        },
                    })
                    account.activities.push(activity._id)
                    // account.myPosts.push(post._id.toString())
                }
                await account.save()
                sendSuccess(ws)
                return
            }
        }
        sendError(ws)
    } catch (ex) {
        console.log(ex)
        sendError(ws)
    }
}

module.exports.changeLikesActivity = async (data, ws) => {
    try {
        if (data.activityId && data.accountId) {
            if (data.add) {
                await Activity.updateOne(
                    { _id: data.activityId },
                    { $addToSet: { likes: data.accountId } },
                    { useFindAndModify: false }
                )
            } else {
                await Activity.updateOne(
                    { _id: data.activityId },
                    { $pull: { likes: data.accountId } },
                    { useFindAndModify: false }
                )
            }
        }
    } catch (ex) {
        console.log(ex)
        sendError(ws)
    }
}

module.exports.deleteActivity = async (data, ws) => {
    try {
        if (data.activityId && data.accountId) {
            await Activity.deleteOne({ _id: data.activityId })
            await Account.updateOne(
                { _id: data.accountId },
                { $pull: { activities: data.activityId } },
                { useFindAndModify: false }
            )
        }
    } catch (ex) {
        console.log(ex)
        sendError(ws)
    }
}
