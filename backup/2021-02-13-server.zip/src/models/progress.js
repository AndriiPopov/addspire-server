const jwt = require('jsonwebtoken')
const mongoose = require('mongoose')
const { mongoLength } = require('../constants/fieldLength')
const stageSchema = require('./schemas/stage')
const types = mongoose.Schema.Types
const increaseVersion = require('../utils/increaseVersion')
const { updateIfCurrentPlugin } = require('mongoose-update-if-current')

const progressSchema = new mongoose.Schema(
    {
        course: String,
        version: String,
        progressSteps: [String],
        owner: String,
        position: {},
        nomap: Boolean,
        status: String,
    },
    { minimize: false }
)
progressSchema.index({ position: '2dsphere' })

progressSchema.plugin(updateIfCurrentPlugin)

progressSchema.pre(
    [
        'update',
        'updateOne',
        'findOneAndUpdate',
        'findByIdAndUpdate',
        'updateMany',
    ],
    increaseVersion
)

module.exports.Progress = mongoose.model('Progress', progressSchema)
