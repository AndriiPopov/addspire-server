const jwt = require('jsonwebtoken')
const mongoose = require('mongoose')
const { mongoLength } = require('../constants/fieldLength')
const notificationSchema = require('./schemas/notification')
const increaseVersion = require('../utils/increaseVersion')
const { updateIfCurrentPlugin } = require('mongoose-update-if-current')
const types = mongoose.Schema.Types

const courseSchema = new mongoose.Schema(
    {
        posts: [String],
        sadmins: [String],
        admins: [String],
        collaborators: [String],
        versions: [String],
        currentVersion: String,
        pendingVersions: [String],
        users: [String],
        currentUsers: [String],
        finishedUsers: [String],
        settings: {},
        notifications: [notificationSchema],
        trend: { type: Number, default: 0 },
        likes: [String],
        followers: [String],
        owner: String,
        name: {
            type: String,
            required: true,
            default: 'New goal',
            maxlength: mongoLength.name,
        },
        date: {
            type: Date,
            default: Date.now,
        },
        derivedCourses: [String],
    },
    { minimize: false }
)

courseSchema.plugin(updateIfCurrentPlugin)

courseSchema.pre(
    [
        'update',
        'updateOne',
        'findOneAndUpdate',
        'findByIdAndUpdate',
        'updateMany',
    ],
    increaseVersion
)

module.exports.Course = mongoose.model('Course', courseSchema)
module.exports.courseSchema = courseSchema
